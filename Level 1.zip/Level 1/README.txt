Welcome to Demystified!

Your first Puzzle :
Take a look at image.jpg and figure out the password for level 2

P.S. Password is all small letters without spaces.
